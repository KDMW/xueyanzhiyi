package planetwars.strategies;

import org.jgrapht.*;
import org.jgrapht.graph.DefaultUndirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;
import planetwars.publicapi.*;
import java.util.*;
import java.util.Dictionary;

public class WellWellWell implements IStrategy{

    private double fightPop = 0.15;// how much more than 1.1 to send out to conquer
    private double fightRatio = 0.75; // how much percent are troop
    private double occupyRatio = 0.15; // how much percent are to send to empty planet
    private double occupyPop = 0.25; // how much pop to send to grab a neutral planet

    private boolean toDraw = true;

    private DefaultUndirectedWeightedGraph<IPlanet, DefaultWeightedEdge> map = new DefaultUndirectedWeightedGraph<IPlanet, DefaultWeightedEdge>(DefaultWeightedEdge.class);
    private HashMap<Integer, IPlanet> dictionary = new HashMap<Integer, IPlanet>();

    public WellWellWell() {

    }

    /**
     * Method where students can observe the state of the system and schedule events to be executed.
     *
     * @param planets          The current state of the system.
     * @param planetOperations Helper methods students can use to interact with the system.
     * @param eventsToExecute  Queue students will add to in order to schedule events.
     */
    @Override
    public void takeTurn(List<IPlanet> planets, IPlanetOperations planetOperations, Queue<IEvent> eventsToExecute) {

        if (toDraw == true) {
            dictionary(planets); //TODO
            drawMap(planets);//TODO
            System.out.println("map and dictionary constructed");
            toDraw = false;
        }

        List<List<IVisiblePlanet>> aList = sort(planets);// update aList

        strategy(aList,planetOperations,eventsToExecute); // update eventsToExecute

    }


   /**
    * divide given list of planets to 3 parts
    * */
    public List<List<IVisiblePlanet>>sort(List<IPlanet> planets){

         List<IVisiblePlanet> conqueredVisiblePlanets= new ArrayList<>();
         List<IVisiblePlanet> enemyVisiblePlanets= new ArrayList<>();
         List<IVisiblePlanet> neutralVisiblePlanets= new ArrayList<>();
         List<List<IVisiblePlanet>> aList = new ArrayList<>();

        aList.add(conqueredVisiblePlanets );
        aList.add(enemyVisiblePlanets);
        aList.add(neutralVisiblePlanets);

        //for planets of given list
        for (IPlanet planet : planets) {
            //if planet is visible and is mine
            if (planet instanceof IVisiblePlanet && ((IVisiblePlanet) planet).getOwner() == Owner.SELF) {
                //add this planet to conquered list
                conqueredVisiblePlanets.add((IVisiblePlanet) planet);

            //if visible, and neutral
            } else if (planet instanceof IVisiblePlanet && ((IVisiblePlanet) planet).getOwner() == Owner.NEUTRAL){
                //send people to empty planet
                neutralVisiblePlanets.add((IVisiblePlanet) planet);

            // visible, enemy's
            } else if (planet instanceof IVisiblePlanet)
                //add this planet to unconquered list
                enemyVisiblePlanets.add((IVisiblePlanet) planet);
        }
        return aList;
    }

    public void strategy(List<List<IVisiblePlanet>> aList,IPlanetOperations planetOperations,Queue<IEvent> eventsToExecute) {

        //for a each planet of mine
        for (IVisiblePlanet sourcePlanet : aList.get(0)) {
            Set<IVisiblePlanet> neighbor = getNeighbors(sourcePlanet);//TODO
            Iterator<IVisiblePlanet> it = neighbor.iterator();
            while (it.hasNext()) {
                IVisiblePlanet nei = it.next();

                //if nei if enemy
                if (nei.getOwner() == Owner.OPPONENT) {
                    ////find smallest connected enemy planets (which mostly front line)
                    //IVisiblePlanet smallestEnemy = getSmallest(enemyVisiblePlanets);

                    // if has enough pop to conquer
                    if (sourcePlanet.getPopulation() * fightRatio > (1.1 + fightPop) * nei.getPopulation()) {
                        //select amount of ppl to fight
                        double transferPopulation = (1.1 + fightPop) * sourcePlanet.getPopulation();

                        //send those population to that planet
                        eventsToExecute.offer(planetOperations.transferPeople(sourcePlanet, nei, (long)transferPopulation));
                    }
                }
                //if nei is neutral
                else if (nei.getOwner() == Owner.NEUTRAL && sourcePlanet.getPopulation()*occupyRatio > 2) {
                    //select amount of ppl to occupy
                    double transferPopulation = occupyPop * sourcePlanet.getPopulation();
                    //send those population to that planet
                    eventsToExecute.offer(planetOperations.transferPeople(sourcePlanet, nei, (long)transferPopulation));

                }// end if
            }// end while hasNext
        }// end for
    }// end method


    /**TODO
     * @param planet
     * @return a list of planets that are neighbor of given planet
     * */
    public Set<IVisiblePlanet> getNeighbors (IPlanet planet ){
        Set<IVisiblePlanet> neiP = null;

        Set<IEdge> edgeSet = planet.getEdges();
        Iterator<IEdge> it = edgeSet.iterator();
        while(it.hasNext()){
            IEdge e = it.next();
            int destID = e.getDestinationPlanetId();
            IVisiblePlanet p = (IVisiblePlanet) dictionary.get(destID);  //TODO get planet from map using destID
            neiP.add(p);
            System.out.println("found one neighbor");
        }

        return neiP;
    }

    //TODO
    public void drawMap(List<IPlanet> planets){
        //construct map here using JGraphT
        for (IPlanet p : planets){
            if (!map.containsVertex(p)) {
                map.addVertex(p);
                Set<IEdge> edges = p.getEdges();

                Iterator<IEdge> it = edges.iterator();

                while (it.hasNext()) {
                    IEdge e = it.next();
                    DefaultWeightedEdge ee = new DefaultWeightedEdge();
                    map.setEdgeWeight(ee,e.getLength());
                    int destID = e.getDestinationPlanetId();
                    IPlanet neiP = dictionary.get(destID);  //TODO get planet from map using destID
                    if (!map.containsVertex(neiP)) {
                        map.addVertex(neiP);
                        map.addEdge(p, neiP, ee);
                    }
                }
            }
        }
    }

    //TODO a dictionary for <int ID IPlanet planet>
    public void dictionary (List<IPlanet> planets){
        for (IPlanet p : planets){
            Integer id = p.getId();
            dictionary.put(id, p);
        }
    }

//========================== Stage TWO :: Strategic Stuff ===========================//
    //TODO when a planet is full, send population to nearby low population planet


   //TODO Find highest habitability planet, spread my people to it alone shortest path
    public Stack<IVisiblePlanet> goMostHabitPlanet(List<IPlanet> planets){
        return null;
    }


    //TODO attack enemy front line planets
    public List<IVisiblePlanet> enemyFrontLine(List<IVisiblePlanet> enemyVisiblePlanets){
        List<IVisiblePlanet> enemyFL = null;
        return enemyFL;
    }

    //TODO make my front line planet strong by supplying population from back line
    public List<IVisiblePlanet> myFrontLine(List<IVisiblePlanet> conqueredVisiblePlanets){
        List<IVisiblePlanet> myFL = null;
        //if a planet in conquered list is connect to enemy planet && enemy is attacking it
        //then this planet is a front line
        return myFL;
    }

    //TODO
    public IVisiblePlanet getSmallest(List<IVisiblePlanet> list){
        //find smallest population one in the unconquered list
        return null;
    }

    //TODO find a shortest path to send population to a destination planet (front line planet)

    //TODO : By seeing incoming shuttles of a visible enemy planet, know it's population size
    // after several round. if it will be huge, avoid attacking it after several rounds.

    //TODO by seeing incoming shuttle to my front line planet,
    // if a huge one (larger than future population + supply shuttles) from enemy is coming,
    // stop sending people to it




    //========================== Miscellaneous ===========================//
    @Override
    public String getName() {
        // this method will be used as your team name on any scoreboards we report.
        return "WellWellWell";
    }

    @Override
    public boolean compete() {
        // return “true” in this method if you want your submission
        // to compete in the class tournament, “false” if not.
        return false;
    }
}
